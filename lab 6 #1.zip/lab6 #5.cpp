#include<stdio.h>
int main()
{
	int level;
	int i=0;
	printf("enter level");
	scanf("%d",&level);
	while(level!=1)
	{
		if(level%2==0)
		{
			level=level/2;
		}
		else
		{
			level=3*level+1;
		}
		i++;
		printf("hour=%d,level=%d\n",i,level);
	}
	printf("total hour=%d",i);
}
