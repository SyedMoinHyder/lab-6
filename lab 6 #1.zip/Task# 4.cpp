#include <stdio.h>

int main()
 {
    char light, button;

    printf("Enter traffic light color (R/Y/G): ");
    scanf(" %c", &light);

    switch (light) {
        case 'R':
        case 'r':
            printf("Has the pedestrian button been pressed? (Y/N): ");
            scanf(" %c", &button);

            switch (button) {
                case 'Y':
                case 'y':
                    printf("Action: Stop and wait, then stop and cross.\n");
                    break;
                case 'N':
                case 'n':
                    printf("Action: Stop and wait.\n");
                    break;
                default:
                    printf("Invalid pedestrian button input.\n");
            }
            break;

        case 'Y':
        case 'y':
            printf("Action: Get ready to stop. Slow down.\n");
            break;

        case 'G':
        case 'g':
            printf("Has the pedestrian button been pressed? (Y/N): ");
            scanf(" %c", &button);

            switch (button) {
                case 'Y':
                case 'y':
                    printf("Action: Go, but watch for pedestrians.\n");
                    break;
                case 'N':
                case 'n':
                    printf("Action: Go.\n");
                    break;
                default:
                    printf("Invalid pedestrian button input.\n");
            }
            break;

        default:
            printf("Invalid traffic light color.\n");
    }

    return 0;
}
