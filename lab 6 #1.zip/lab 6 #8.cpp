#include<stdio.h>
int main()
{
	int temprature[8];
	int i;
	int max;
	int min;
	int second;
	for(i=0;i<8;i++)
	{
		printf("enter  temprature\n");
		scanf("%d",&temprature[i]);

	}
		min=temprature[0];
		max=temprature[0];
		second=temprature[0];
	for(i=0;i<8;i++)
	{
		if(temprature[i]>max)
		{
		max=temprature[i];
		}
		if(temprature[i]<min)
		{
			min=temprature[i];
		}
	}
	
	for(i=0;i<8;i++)
	{
		if(temprature[i]>second&&temprature[i]<max)
		{
			second=temprature[i];
		}
	}
	printf("higest temprature=%d",max);
	printf("lowest temprature=%d",min);
	printf("second highest temprature=%d",second);
	return 0;
	
}
