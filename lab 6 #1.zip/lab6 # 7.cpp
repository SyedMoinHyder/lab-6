#include<stdio.h>
int main()
{
	int item;
	do
	{
		printf("enter 1 for add item\n");
		printf("enter 2 for remove item\n");
		printf("enter 3 for view total\n");
		printf("enter 4 for checkout\n");
		scanf("%d",&item);
		if(item==4)
		{
			break;
		}
		if(item>4)
		{
			printf("ERROR\n");
		}
	}while(item!=4);
	return 0;
	
}
