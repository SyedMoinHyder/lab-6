#include<stdio.h>
int main()
{
	int n;
	int score;
	int total=0;
	int average;
	int i;
	printf("Enter number of students\n");
	scanf("%d",&n);
	
	for(i=1;i<=n;i++)
	{
		printf("Enter test score\n");
		scanf("%d",&score);
		total=total+score;
	}
	average=total/n;
	printf("class total=%d\n",total);
	printf("class average=%d\n",average);
	return 0;
}
