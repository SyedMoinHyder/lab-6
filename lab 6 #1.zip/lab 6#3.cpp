#include<stdio.h>
int main()
{
	float amount;
	float deposit=500;
	float rate=10;
	int year;
	int i;
	amount=deposit;
	printf("enter year you want to calculate\n");
	scanf("%d",&year);
	for(i=1;i<=year;i++)
    {
    	amount=amount*(1+rate/100);
		}
	printf("Your amount is %.2f\n",amount);	
	return 0;
}
