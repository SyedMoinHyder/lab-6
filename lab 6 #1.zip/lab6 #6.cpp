#include<stdio.h>
int main()
{
	int marks;
	int i=0;
	do
	{
	printf("enter your marks\n");
	scanf("%d",&marks);
	if (marks>100||marks<0)
	{
	printf("invalid marks");
    }
	}while(marks>100||marks<0);
	if(marks>=50)
	{
		printf("pass");
	}
	else
	{
		printf("fail");
	}
	return 0;
}
