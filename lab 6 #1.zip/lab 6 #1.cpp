#include<stdio.h>
int main()
{
    int	prize=500;
	int i;
	int show=i;
	for(i=1;i<=10;i++)
	{
	   printf("show =%d=%d\n",i,prize);
	   prize=prize+50;	
	}
	return 0;
}
