//A signup form takes a username (up to 20 characters) as input. Count how many vowels and
//consonants it contains (a basic strength heuristic), then convert the username to all uppercase to store
//it in the system's case-insensitive username database.
#include<stdio.h>
#include<ctype.h>
int main()
{
	char username[20];
	int i;
	int m=0;
	int n=0;
	for(i=0;i<20;i++)
	{
		printf("enter you username\n");
		scanf(" %c",&username[i]);
		if(username[i]=='a'||username[i]=='e'||username[i]=='i'||username[i]=='o'||username[i]=='u')
		{
			m++;
		}
		else
		{
			n++;
		}
		username[i]=toupper(username[i]);
		
	}
	for(i=0;i<20;i++)
	{
		printf("%c",username[i]);
	}
	printf("vowells are=%d",m);
	printf("consonent are=%d",n);
    return 0;
}
